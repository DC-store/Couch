package com.db;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CoucchApplicationTests {

	@Test
	void contextLoads() {
	}

}
