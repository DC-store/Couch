package com.db.model.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.couchbase.client.java.Bucket;
import com.couchbase.client.java.Cluster;
import com.db.model.datata;

@RestController
public class ControllingClasss {
	@Autowired
	private Cluster cluster;
	
	
	@Autowired
	private Bucket bucket;
	
	@PostMapping("/updating")
	public ResponseEntity<String> update(@RequestBody datata dat) {
		System.out.println(dat.getId());
		int i=dat.getId();
		String s=String.valueOf(i);  
		System.out.println(dat.getName());
		bucket.defaultCollection().insert(s, dat);
		
		return new ResponseEntity<String>("sucessfully inserted", HttpStatus.ACCEPTED);
	}

}
