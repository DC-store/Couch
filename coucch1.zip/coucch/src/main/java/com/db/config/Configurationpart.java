package com.db.config;

import java.time.Duration;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.couchbase.client.java.Bucket;
import com.couchbase.client.java.Cluster;
import com.couchbase.client.java.Scope;
import com.couchbase.client.java.manager.bucket.BucketSettings;
import com.couchbase.client.java.manager.bucket.BucketType;
import com.couchbase.transactions.TransactionDurabilityLevel;
import com.couchbase.transactions.Transactions;
import com.couchbase.transactions.config.TransactionConfigBuilder;

@Configuration
public class Configurationpart {
	
	
	static String connectionString = "10.0.5.52";
	  static String username = "sid";
	  static String password = "sid@1234";
	  static String bucketName = "USER";
	
	  @Bean
	    public Cluster getCouchbaseCluster(){
		  Cluster cluster = Cluster.connect(connectionString, username, password);
		  Bucket bucket = cluster.bucket(bucketName);
		    bucket.waitUntilReady(Duration.parse("PT10S"));
		  Scope scope = bucket.scope("_default");
		    com.couchbase.client.java.Collection collection = scope.collection("_default");
		   /* MutationResult upsertResult = collection.upsert(
		            "my-document",
		            JsonObject.create().put("name", "mike"));*/
	        return cluster;
	    }
	  @Bean
	    public Bucket getCouchbaseBucket(Cluster cluster){

	        //Creates the cluster if it does not exist yet
	        if( !cluster.buckets().getAllBuckets().containsKey(bucketName)) {
	            cluster.buckets().createBucket(BucketSettings.create(bucketName)
	                    .bucketType(BucketType.COUCHBASE)
	                    .ramQuotaMB(256));
	        }
	        return cluster.bucket(bucketName);
	    }
	  @Bean
	    public Transactions transactions(final Cluster couchbaseCluster) {
	      return Transactions.create(
	        couchbaseCluster,
	        TransactionConfigBuilder.create()
	          .durabilityLevel(TransactionDurabilityLevel.NONE)
	                // The configuration can be altered here, but in most cases the defaults are fine.
	          .build()
	      );
	    }
	

}
