package com.db;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CoucchApplication {

	public static void main(String[] args) {
		SpringApplication.run(CoucchApplication.class, args);
		System.out.println("work");
	}

}
